
python-money
============

Primitives for working with money and currencies in Python


Installation
============

You can install this project directly from the git repository using pip:

    $ pip install -e git+http://github.com/poswald/python-money.git@0.0.1#egg=python-money
